**Project Description**
GMap.NET is a simple server control to allow easy implementation of google maps into any C# or VB.NET project without the use of any code and includes seamless integration with a .Kml file.

The ease of use here is that you can simply create the KML file in Google Earth, save it, publish it to the web and easily integrate it into a web page with no coding.

**This code is open to anyone to improve/add/upgrade/break :)**

**If you like this project you can show your appreciation by making a small donation:**  [PayPal Donation](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=RKYC2Z8B4QW54&lc=ZA&item_name=Halcyonetic%20Studios&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)